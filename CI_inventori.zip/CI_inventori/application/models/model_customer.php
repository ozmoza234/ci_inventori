<?php
defined('BASEPATH') or exit('No direct script access allowed');

class model_customer extends ci_model
{

    public function tampil_list_data()
    {
        $query = "SELECT * FROM customer";
        return $this->db->query($query);
    }

    public function input_data($data)
    {
        $this->db->insert('customer', $data);
    }

    public function ambil_data($id)
    {
        $data = array('id_customer' => $id);
        return $this->db->get_where('customer', $data);
    }

    public function edit_data($data, $id)
    {
        $this->db->where('id_customer', $id);
        $this->db->update('customer', $data);
    }

    public function hapus_data($id)
    {
        $this->db->where('id_customer', $id);
        $this->db->delete('customer');
    }
}
