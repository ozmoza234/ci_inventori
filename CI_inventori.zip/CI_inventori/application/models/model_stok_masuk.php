<?php
defined('BASEPATH') or exit('No direct script access allowed');

class model_stok_masuk extends ci_model
{

    public function tampil_list_data()
    {
        $query = "SELECT
                    `stok_masuk`.*,
                    `stok_masuk`.`id_supplier` AS `id_supplier1`,
                    `supplier`.`nama_supplier`,
                    `stok_masuk`.`id_barang` AS `id_barang1`,
                    `barang`.`nama_barang`
                FROM
                    `barang`
                    INNER JOIN `stok_masuk` ON `stok_masuk`.`id_barang` = `barang`.`id_barang`
                    INNER JOIN `supplier` ON `stok_masuk`.`id_supplier` = `supplier`.`id_supplier`";
        return $this->db->query($query);
    }

    public function input_data($data)
    {
        $this->db->insert('stok_masuk', $data);
    }

    public function ambil_data($id)
    {
        $data = array('id_stok_masuk' => $id);
        return $this->db->get_where('stok_masuk', $data);
    }

    public function edit_data($data, $id)
    {
        $this->db->where('id_stok_masuk', $id);
        $this->db->update('stok_masuk', $data);
    }

    public function hapus_data($id)
    {
        $this->db->where('id_stok_masuk', $id);
        $this->db->delete('stok_masuk');
    }
}
