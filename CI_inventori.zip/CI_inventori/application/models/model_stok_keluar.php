<?php
defined('BASEPATH') or exit('No direct script access allowed');

class model_stok_keluar extends ci_model
{

    public function tampil_list_data()
    {
        $query = "SELECT
                    `stok_keluar`.*,
                    `stok_keluar`.`id_customer` AS `id_customer1`,
                    `customer`.`nama_customer`,
                    `stok_keluar`.`id_barang` AS `id_barang1`,
                    `barang`.`nama_barang`
                FROM
                    `barang`
                    INNER JOIN `stok_keluar` ON `stok_keluar`.`id_barang` = `barang`.`id_barang`
                    INNER JOIN `customer` ON `stok_keluar`.`id_customer` = `customer`.`id_customer`";
        return $this->db->query($query);
    }

    public function input_data($data)
    {
        $this->db->insert('stok_keluar', $data);
    }

    public function ambil_data($id)
    {
        $data = array('id_stok_keluar' => $id);
        return $this->db->get_where('stok_keluar', $data);
    }

    public function edit_data($data, $id)
    {
        $this->db->where('id_stok_keluar', $id);
        $this->db->update('stok_keluar', $data);
    }

    public function hapus_data($id)
    {
        $this->db->where('id_stok_keluar', $id);
        $this->db->delete('stok_keluar');
    }
}
