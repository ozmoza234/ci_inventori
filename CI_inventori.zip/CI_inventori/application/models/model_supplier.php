<?php
defined('BASEPATH') or exit('No direct script access allowed');

class model_supplier extends ci_model
{

    public function tampil_list_data()
    {
        $query = "SELECT * FROM supplier";
        return $this->db->query($query);
    }

    public function input_data($data)
    {
        $this->db->insert('supplier', $data);
    }

    public function ambil_data($id)
    {
        $data = array('id_supplier' => $id);
        return $this->db->get_where('supplier', $data);
    }

    public function edit_data($data, $id)
    {
        $this->db->where('id_supplier', $id);
        $this->db->update('supplier', $data);
    }

    public function hapus_data($id)
    {
        $this->db->where('id_supplier', $id);
        $this->db->delete('supplier');
    }
}
