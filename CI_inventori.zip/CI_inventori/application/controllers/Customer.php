<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Customer extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('model_customer');
    }

    public function index()
    {
        $data['tampil_list_data_customer'] = $this->model_customer->tampil_list_data(); //ambil function di model => tampung ke $data
        $this->load->view('customer/tampil_customer', $data); //panggi
    }

    public function tambah_data_customer()
    {
        if (isset($_POST['submit'])) {
            $nama_customer = $this->input->post("nama_customer");
            $alamat = $this->input->post("alamat");
            $telp = $this->input->post("telp");
            $data = array(
                'nama_customer' => $nama_customer,
                'alamat' => $alamat,
                'telp' => $telp
            );
            $this->model_customer->input_data($data);
            redirect('customer');
        } else {
            $this->load->view('customer/input_customer');
        }
    }

    public function tampil_data_yang_mau_di_edit()
    {
        if (isset($_POST['submit'])) {
            $id = $this->input->post('id_customer');
            $nama_customer = $this->input->post("nama_customer");
            $alamat = $this->input->post("alamat");
            $telp = $this->input->post("telp");
            $data = array(
                'id_customer' => $id,
                'nama_customer' => $nama_customer,
                'alamat' => $alamat,
                'telp' => $telp
            );
            $this->model_customer->edit_data($data, $id);
            redirect('customer');
        } else {
            $id = $this->uri->segment(3);
            $data['data_edit'] = $this->model_customer->ambil_data($id)->row_array();
            $this->load->view('customer/edit_customer', $data);
        }
    }

    public function hapus_data()
    {
        $id = $this->uri->segment(3);
        $this->model_customer->hapus_data($id);
        redirect('customer');
    }
}
