<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Supplier extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('model_supplier');
    }

    public function index()
    {
        $data['tampil_list_data_supplier'] = $this->model_supplier->tampil_list_data(); //ambil function di model => tampung ke $data
        $this->load->view('supplier/tampil_supplier', $data); //panggi
    }

    public function tambah_data_supplier()
    {
        if (isset($_POST['submit'])) {
            $nama_supplier = $this->input->post("nama_supplier");
            $alamat = $this->input->post("alamat");
            $telp = $this->input->post("telp");
            $data = array(
                'nama_supplier' => $nama_supplier,
                'alamat' => $alamat,
                'telp' => $telp
            );
            $this->model_supplier->input_data($data);
            redirect('supplier');
        } else {
            $this->load->view('supplier/input_supplier');
        }
    }

    public function tampil_data_yang_mau_di_edit()
    {
        if (isset($_POST['submit'])) {
            $id = $this->input->post('id_supplier');
            $nama_supplier = $this->input->post("nama_supplier");
            $alamat = $this->input->post("alamat");
            $telp = $this->input->post("telp");
            $data = array(
                'id_supplier' => $id,
                'nama_supplier' => $nama_supplier,
                'alamat' => $alamat,
                'telp' => $telp
            );
            $this->model_supplier->edit_data($data, $id);
            redirect('supplier');
        } else {
            $id = $this->uri->segment(3);
            $data['data_edit'] = $this->model_supplier->ambil_data($id)->row_array();
            $this->load->view('supplier/edit_supplier', $data);
        }
    }

    public function hapus_data()
    {
        $id = $this->uri->segment(3);
        $this->model_supplier->hapus_data($id);
        redirect('supplier');
    }
}
