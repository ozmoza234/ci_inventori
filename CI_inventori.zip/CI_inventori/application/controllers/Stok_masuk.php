<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Stok_masuk extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('model_stok_masuk');
        $this->load->model('model_barang');
        $this->load->model('model_supplier');
    }

    public function index()
    {
        $data['tampil_list_data_stok_masuk'] = $this->model_stok_masuk->tampil_list_data(); //ambil function di model => tampung ke $data
        $this->load->view('stok_masuk/tampil_stok_masuk', $data); //panggi
    }

    public function tambah_data_stok_masuk()
    {
        if (isset($_POST['submit'])) { //jika sudah pencet submit
            $id_supplier = $this->input->post("id_supplier");
            $id_barang = $this->input->post("id_barang");
            $qty = $this->input->post("qty");
            $tanggal = $this->input->post("tanggal");
            $data = array(
                'id_supplier' => $id_supplier,
                'id_barang' => $id_barang,
                'qty' => $qty,
                'tanggal' => $tanggal
            );
            $this->model_stok_masuk->input_data($data);
            redirect('stok_masuk');
        } else { //jika belum
            $data['supplier'] = $this->model_supplier->tampil_list_data();
            $data['barang'] = $this->model_barang->tampil_list_data();
            $this->load->view('stok_masuk/input_stok_masuk', $data); //load view, beserta mengirimkan data ke view
        }
    }

    public function tampil_data_yang_mau_di_edit()
    {
        if (isset($_POST['submit'])) {
            $id = $this->input->post('id_stok_masuk');
            $id_supplier = $this->input->post("id_supplier");
            $id_barang = $this->input->post("id_barang");
            $qty = $this->input->post("qty");
            $tanggal = $this->input->post("tanggal");
            $data = array(
                'id_stok_masuk' => $id,
                'id_supplier' => $id_supplier,
                'id_barang' => $id_barang,
                'qty' => $qty,
                'tanggal' => $tanggal
            );
            $this->model_stok_masuk->edit_data($data, $id);
            redirect('stok_masuk');
        } else {
            $id = $this->uri->segment(3);
            $data['data_edit'] = $this->model_stok_masuk->ambil_data($id)->row_array();
            $this->load->view('stok_masuk/edit_stok_masuk', $data);
        }
    }

    public function hapus_data()
    {
        $id = $this->uri->segment(3);
        $this->model_stok_masuk->hapus_data($id);
        redirect('stok_masuk');
    }
}
