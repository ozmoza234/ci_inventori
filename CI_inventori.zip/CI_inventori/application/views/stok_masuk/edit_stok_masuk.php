<?php
echo form_open('/tampil_data_yang_mau_di_edit'); //hasil inputan dilempar ke Controller
?>

<table border='1'>
    <tr>
        <td>Masukan Nama supplier</td>
        <td>
            <select name="id_supplier">
                <option value="<?php echo $data_edit['nama_supplier'] ?>">---PILIH SUPPLIER---</option>
                <?php foreach ($supplier->result() as $tampil) { ?>
                    <option value="<?php echo $tampil->id_supplier ?>"><?php echo $tampil->nama_supplier ?></option>
                <?php } ?>
            </select>
        </td>
    </tr>
    <tr>
        <td>Nama Barang</td>
        <td>
            <select name="id_barang">
                <option value="">---PILIH BARANG---</option>
                <?php foreach ($barang->result() as $tampil) { ?>
                    <option value="<?php echo $tampil->id_barang ?>"><?php echo $tampil->nama_barang ?></option>
                <?php } ?>
            </select>
        </td>
    </tr>
    <tr>
        <td>Jumlah</td>
        <td>
            <input type="text" name="qty">
        </td>
    </tr>
    <tr>
        <td>Tanggal</td>
        <td>
            <input type="date" name="tanggal">
        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <input type="hidden" name="id_stok_masuk" value="<?php echo $data_edit['id_stok_masuk']; ?>" />
            <input type="submit" name="submit">
        </td>
    </tr>
</table>