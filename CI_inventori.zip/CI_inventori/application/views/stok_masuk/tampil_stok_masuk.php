<table border="1" />
<tr>
    <td>Nama Supplier</td>
    <td>Nama Barang</td>
    <td>Quantity</td>
    <td>Tanggal</td>
    <td colspan="2">Action</td>
</tr>
<?php foreach ($tampil_list_data_stok_masuk->result() as $tampil) { ?>
    <tr>
        <td><?php echo $tampil->nama_supplier ?></td>
        <td><?php echo $tampil->nama_barang ?></td>
        <td><?php echo $tampil->qty ?></td>
        <td><?php echo $tampil->tanggal ?></td>
        <td><a href="<?php echo base_url() ?>index.php/stok_masuk/tampil_data_yang_mau_di_edit/<?php echo $tampil->id_stok_masuk; ?>">EDIT</td>
        <td><a href="<?php echo base_url() ?>index.php/stok_masuk/hapus_data/<?php echo $tampil->id_stok_masuk; ?>">HAPUS</td>
    </tr>
<?php } ?>
</table>