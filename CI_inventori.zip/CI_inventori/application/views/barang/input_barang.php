<?php
    echo form_open('barang/tambah_data_barang'); //hasil inputan dilempar ke Controller
?>

<table border='1'>
    <tr>
        <td>Masukan Nama Barang</td>
        <td>
            <input type="text" name="nama_barang">
        </td>
    </tr>
    <tr>
        <td>Masukan Stok Barang</td>
        <td>
            <input type="text" name="stok">
        </td>
    </tr>
    <tr>
        <td>Masukan Status Barang</td>
        <td>
            <input type="text" name="status">
        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <input type="submit" name="submit">
        </td>
    </tr>