<table border="1"/>
    <tr>
        <td>Nama Barang</td>
        <td>Quantity</td>
        <td>Status</td>
        <td colspan="2">Action</td>
    </tr>
    <?php foreach ($tampil_list_data_barang -> result() as $tampil){ ?>
        <tr>
            <td><?php echo $tampil -> nama_barang ?></td>
            <td><?php echo $tampil -> stok?></td>
            <td><?php echo $tampil -> status?></td>
            <td><a href="<?php echo base_url()?>index.php/barang/tampil_data_yang_mau_di_edit/<?php echo $tampil -> id_barang;?>">EDIT</td>
            <td><a href="<?php echo base_url()?>index.php/barang/hapus_data/<?php echo $tampil -> id_barang;?>">HAPUS</td>
        </tr>
    <?php } ?>
</table>