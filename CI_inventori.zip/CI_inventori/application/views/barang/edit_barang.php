<?php
    echo form_open('barang/tampil_data_yang_mau_di_edit'); //hasil inputan dilempar ke Controller
?>

<table border='1'>
    <tr>
        <td>Masukan Nama Barang</td>
        <td>
            <input type="text" name="nama_barang" value="<?php echo $data_edit['nama_barang'];?>"/>
        </td>
    </tr>
    <tr>
        <td>Masukan Stok Barang</td>
        <td>
            <input type="text" name="stok" value="<?php echo $data_edit['stok'];?>"/>
        </td>
    </tr>
    <tr>
        <td>Masukan Status Barang</td>
        <td>
            <input type="text" name="status" value="<?php echo $data_edit['status'];?>"/>
        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <input type="hidden" name="id_barang" value="<?php echo $data_edit['id_barang'];?>"/>
            <input type="submit" name="submit">
        </td>
    </tr>