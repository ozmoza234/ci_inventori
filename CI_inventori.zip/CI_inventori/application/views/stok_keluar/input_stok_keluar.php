<?php
echo form_open('stok_keluar/tambah_data_stok_keluar'); //hasil inputan dilempar ke Controller
?>

<table border='1'>
    <tr>
        <td>Masukan Nama customer</td>
        <td>
            <select name="id_customer">
                <option value="">---PILIH customer---</option>
                <?php foreach ($customer->result() as $tampil) { ?>
                    <option value="<?php echo $tampil->id_customer ?>"><?php echo $tampil->nama_customer ?></option>
                <?php } ?>
            </select>
        </td>
    </tr>
    <tr>
        <td>Nama Barang</td>
        <td>
            <select name="id_barang">
                <option value="">---PILIH BARANG---</option>
                <?php foreach ($barang->result() as $tampil) { ?>
                    <option value="<?php echo $tampil->id_barang ?>"><?php echo $tampil->nama_barang ?></option>
                <?php } ?>
            </select>
        </td>
    </tr>
    <tr>
        <td>Jumlah</td>
        <td>
            <input type="text" name="qty">
        </td>
    </tr>
    <tr>
        <td>Tanggal</td>
        <td>
            <input type="date" name="tanggal">
        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <input type="submit" name="submit">
        </td>
    </tr>