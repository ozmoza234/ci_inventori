<table border="1" />
<tr>
    <td>Nama customer</td>
    <td>Nama Barang</td>
    <td>Quantity</td>
    <td>Tanggal</td>
    <td colspan="2">Action</td>
</tr>
<?php foreach ($tampil_list_data_stok_keluar->result() as $tampil) { ?>
    <tr>
        <td><?php echo $tampil->nama_customer ?></td>
        <td><?php echo $tampil->nama_barang ?></td>
        <td><?php echo $tampil->qty ?></td>
        <td><?php echo $tampil->tanggal ?></td>
        <td><a href="<?php echo base_url() ?>index.php/stok_keluar/tampil_data_yang_mau_di_edit/<?php echo $tampil->id_stok_keluar; ?>">EDIT</td>
        <td><a href="<?php echo base_url() ?>index.php/stok_keluar/hapus_data/<?php echo $tampil->id_stok_keluar; ?>">HAPUS</td>
    </tr>
<?php } ?>
</table>