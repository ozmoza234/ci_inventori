<?php
echo form_open('customer/tampil_data_yang_mau_di_edit'); //hasil inputan dilempar ke Controller
?>

<table border='1'>
    <tr>
        <td>Masukan Nama customer</td>
        <td>
            <input type="text" name="nama_customer" value="<?php echo $data_edit['nama_customer']; ?>" />
        </td>
    </tr>
    <tr>
        <td>Masukan alamat customer</td>
        <td>
            <input type="text" name="alamat" value="<?php echo $data_edit['alamat']; ?>" />
        </td>
    </tr>
    <tr>
        <td>Masukan telp customer</td>
        <td>
            <input type="text" name="telp" value="<?php echo $data_edit['telp']; ?>" />
        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <input type="hidden" name="id_customer" value="<?php echo $data_edit['id_customer']; ?>" />
            <input type="submit" name="submit">
        </td>
    </tr>