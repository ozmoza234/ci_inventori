<table border="1" />
<tr>
    <td>Nama customer</td>
    <td>Quantity</td>
    <td>telp</td>
    <td colspan="2">Action</td>
</tr>
<?php foreach ($tampil_list_data_customer->result() as $tampil) { ?>
    <tr>
        <td><?php echo $tampil->nama_customer ?></td>
        <td><?php echo $tampil->alamat ?></td>
        <td><?php echo $tampil->telp ?></td>
        <td><a href="<?php echo base_url() ?>index.php/customer/tampil_data_yang_mau_di_edit/<?php echo $tampil->id_customer; ?>">EDIT</td>
        <td><a href="<?php echo base_url() ?>index.php/customer/hapus_data/<?php echo $tampil->id_customer; ?>">HAPUS</td>
    </tr>
<?php } ?>
</table>