<?php
echo form_open('customer/tambah_data_customer'); //hasil inputan dilempar ke Controller
?>

<table border='1'>
    <tr>
        <td>Masukan Nama customer</td>
        <td>
            <input type="text" name="nama_customer">
        </td>
    </tr>
    <tr>
        <td>Masukan alamat customer</td>
        <td>
            <input type="text" name="alamat">
        </td>
    </tr>
    <tr>
        <td>Masukan telp customer</td>
        <td>
            <input type="text" name="telp">
        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <input type="submit" name="submit">
        </td>
    </tr>