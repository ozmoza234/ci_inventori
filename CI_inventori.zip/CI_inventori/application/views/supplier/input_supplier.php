<?php
echo form_open('supplier/tambah_data_supplier'); //hasil inputan dilempar ke Controller
?>

<table border='1'>
    <tr>
        <td>Masukan Nama supplier</td>
        <td>
            <input type="text" name="nama_supplier">
        </td>
    </tr>
    <tr>
        <td>Masukan alamat supplier</td>
        <td>
            <input type="text" name="alamat">
        </td>
    </tr>
    <tr>
        <td>Masukan telp supplier</td>
        <td>
            <input type="text" name="telp">
        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <input type="submit" name="submit">
        </td>
    </tr>