<?php
echo form_open('supplier/tampil_data_yang_mau_di_edit'); //hasil inputan dilempar ke Controller
?>

<table border='1'>
    <tr>
        <td>Masukan Nama supplier</td>
        <td>
            <input type="text" name="nama_supplier" value="<?php echo $data_edit['nama_supplier']; ?>" />
        </td>
    </tr>
    <tr>
        <td>Masukan alamat supplier</td>
        <td>
            <input type="text" name="alamat" value="<?php echo $data_edit['alamat']; ?>" />
        </td>
    </tr>
    <tr>
        <td>Masukan telp supplier</td>
        <td>
            <input type="text" name="telp" value="<?php echo $data_edit['telp']; ?>" />
        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <input type="hidden" name="id_supplier" value="<?php echo $data_edit['id_supplier']; ?>" />
            <input type="submit" name="submit">
        </td>
    </tr>